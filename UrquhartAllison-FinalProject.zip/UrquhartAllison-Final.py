#this is a program that brings up a GUI displaying a menu, and ordering system,
#and a summary screen.
import tkinter as tk
from tkinter import ttk
from tkinter.ttk import Label
from tkinter import *

#defining the function for closing the program
def closeWindows(summary, menu, order):
    summary.destroy()
    order.destroy()
    menu.destroy()

#defining the input validation function
def validate(customerName, order):
    name = customerName.get()#name is the local variable for the customer's name
    if len(name.strip()) == 0 or not name.isalpha():
        error = Label(order,text="Please enter a valid name.")
        error.place(relx=0.5, rely=0.75, anchor='nw')
        return False
    return True

#defining the orderPlaced function
def orderPlaced(drinkVariable, sizeVariable, snackVariable, customerName,
                specialInstructions, menu, order):

    #calling the input validation module
    if not validate(customerName, order):
        return
    
    #attributes of the window
    summary = tk.Toplevel()#summary is the final order summary window
    summary.title("Capybara Coffee")
    summary.geometry("700x400+350+225")
    summary.resizable(True, True)
    summary.attributes("-topmost", 1)
    summary.iconbitmap("capybaracoffeeicon.ico")
    summary['bg']='#c5c395'
    
    #the label and placement for a thank you message
    thankYou = Label(summary,
                     text="Thank you for ordering from Capybara Coffee!",
                     font=(20))#a label
    thankYou.place(relx=0.5, rely=0.1, anchor='n')

    #the label and placement for an order summary text
    orderSummary = Label(summary, text="Order Summary:")#a label
    orderSummary.place(relx=0.5, rely=0.2, anchor='n')

    #the label and placement for the drink item on the summary
    drinkSummary = Label(summary, text=" ")#label that shows the drink choice
    drinkSummary.place(relx=0.45, rely=0.3, anchor='nw')

    #the label and placement for the size on the summary
    sizeSummary = Label(summary, text=" ")
    sizeSummary.place(relx=0.37, rely=0.3, anchor='nw')

    #the label and placement for the snack item on the summary
    snackSummary = Label(summary, text=" ")#label that shows the snack choice
    snackSummary.place(relx=0.5, rely=0.4, anchor='n')

    #the label and placement for the special instructions on the summary
    instructionsSummary = Label(summary, text=" ")#label that shows the instructions
    instructionsSummary.place(relx=0.5, rely=0.5, anchor='n')

    #the label and placement for the name on the summary
    nameSummary = Label(summary, text=" ")#label that shows the name
    nameSummary.place(relx=0.5, rely=0.6, anchor='n')

    #getting the drink, size and snack item and configuring the labels
    drinkItems = drinkVariable.get()#local variable for drink choice
    snackItems = snackVariable.get()#local variable for snack choice
    size = sizeVariable.get()#local variable for size choice
    drinkSummary.config(text=drinkItems)
    snackSummary.config(text=snackItems)
    sizeSummary.config(text=size)

    #getting the special instructions and name and configuring the labels
    instructions = specialInstructions.get()#local variable for instructions
    name = customerName.get()#local variable for customer's name
    theInstructions = f"Special Instructions: {instructions}"
    forName = f"For: {name}"
    instructionsSummary.config(text=theInstructions)
    nameSummary.config(text=forName)

    #the button and configuration for closing the program
    close = ttk.Button(summary, text="Close")#button to close all windows
    close.configure(command=lambda: closeWindows(summary, menu, order))
    close.place(relx=0.5, rely=0.9, anchor='s')

#defining the orderNow function
def orderNow(menu):
    #attributes of the window
    order = tk.Toplevel()#order is the ordering window
    order.title("Capybara Coffee")
    order.geometry("1400x700+50+50")
    order.resizable(True, True)
    order.attributes("-topmost", 1)
    order.iconbitmap("capybaracoffeeicon.ico")
    order['bg']='#c5c395'

    #the label and placement for the choose drink text
    chooseDrink = Label(order, text="Choose a drink", font=(22))#a label
    chooseDrink.place(relx=0.3, rely=0.3, anchor='nw')

    #the label and placement for the choose snack text
    chooseSnack = Label(order, text="Choose a snack", font=(22))#a label
    chooseSnack.place(relx=0.7, rely=0.3, anchor='ne')

    #the label for the size text
    sizeLabel = Label(order, text="Size:")
    sizeLabel.place(relx=0.3, rely=0.46)

    #the drop down menu for the drink
    drinkVariable = StringVar(order)#drinkVariable is the drink choice
    drinkVariable.set("Black Coffee")
    w = OptionMenu(order, drinkVariable, "Black Coffee", "Caramel Macchiato",
                   "White Chocolate Mocha", "Cold Brew", "Irish Cream Latte",
                   "Frozen Coffee", "Iced Tea", "Prickly Pear Energizer")
    w.place(relx=0.3, rely=0.4, anchor='nw')

    #the drop down menu for the snack
    snackVariable = StringVar(order)#snackVariable is the snack choice
    snackVariable.set("Pound Cake")
    w = OptionMenu(order, snackVariable, "Pound Cake", "Banana Bread",
                   "Cream Cheese Danish", "Muffin", "Cannoli", "Cake Pop",
                   "Cookie", "Brownie", "Biscotti")
    w.place(relx=0.6, rely=0.4, anchor='nw')

    #the drop down menu for size
    sizeVariable = StringVar(order)#sizeVariable is the size choice
    sizeVariable.set("Small")
    w = OptionMenu(order, sizeVariable, "Small", "Medium",
                   "Large")
    w.place(relx=0.3, rely=0.5, anchor='nw')

    #the label and placement for the special instructions text
    instructions = Label(order, text="Special Instructions:")
    instructions.place(relx=0.4, rely=0.6, anchor='nw')

    #the entry box for the special instructions
    specialInstructions = tk.StringVar()#specialInstructions is the instructions
    instructionsEntry = ttk.Entry(order, textvariable=specialInstructions)
    instructionsEntry.place(relx=0.5, rely=0.6, anchor='nw')

    #the label and placement for the name text
    name = Label(order, text="Name:")
    name.place(relx=0.4, rely=0.7, anchor='nw')

    #the entry box for the customer name
    customerName = tk.StringVar()#customerName is the customer's name
    nameEntry = ttk.Entry(order, textvariable=customerName)
    nameEntry.place(relx=0.5, rely=0.7, anchor='nw')

    #the button and configuration for the place order button
    placeOrder= ttk.Button(order, text="Place Order!")#the place order button
    placeOrder.configure(command=lambda: orderPlaced(drinkVariable, sizeVariable,
                                                     snackVariable, customerName,
                                                     specialInstructions, menu,
                                                     order))
    placeOrder.place(relx=0.5, rely=0.9, anchor='s')


    order.mainloop()

#the main menu window with attributes       
menu = tk.Tk()#menu is the main window
menu.title("Capybara Coffee")
menu.geometry("1400x700+50+50")
menu.resizable(True, True)
menu.attributes("-topmost", 1)
menu.iconbitmap("capybaracoffeeicon.ico")
menu['bg']='#c5c395'

#the label and placement for the drinks text
drinks = Label(menu, text="Drinks", font=(26))#drinks is the label
drinks.place(relx=0.2, rely=.05, anchor='nw')

#the label and placement for the snacks text
snacks = Label(menu, text="Snacks", font=(26))#snacks is the label
snacks.place(relx=0.8, rely=0.05, anchor='ne')

#the button and configuration for the order now button
orderButton = ttk.Button(menu, text="Order Now!")#orderButton is the order button
orderButton.configure(command=lambda: orderNow(menu))
orderButton.place(relx=0.5, rely=0.9, anchor='s')

#calling the main menu window and starting the GUI
menu.mainloop()
